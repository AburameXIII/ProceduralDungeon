// Fill out your copyright notice in the Description page of Project Settings.


#include "Dungeon.h"

// Sets default values
ADungeon::ADungeon()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	DunGen = CreateDefaultSubobject<UDungeonGen>(TEXT("DungeonGenerator"));

}

// Called when the game starts or when spawned
void ADungeon::BeginPlay()
{
	Super::BeginPlay();
	
	
	TArray<FTile> Tiles = DunGen->Generate();

	for (FTile t : Tiles) {
		if (t.Type == ETileType::Wall) {

			FVector Location = FVector(100.f * t.Coordinates.X, 100.f * t.Coordinates.Y, 0.f);

			GetWorld()->SpawnActor<ABlock>(ABlock::StaticClass(), Location, FRotator::ZeroRotator);
		}
		else if (t.Type == ETileType::RoomWall) {
			FVector Location = FVector(100.f * t.Coordinates.X, 100.f * t.Coordinates.Y, 0.f);

			ABlock* RoomWallBlock = GetWorld()->SpawnActor<ABlock>(ABlock::StaticClass(), Location, FRotator::ZeroRotator);
			RoomWallBlock->SetRoomWall();
		}
	}
	
}


// Called every frame
void ADungeon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

