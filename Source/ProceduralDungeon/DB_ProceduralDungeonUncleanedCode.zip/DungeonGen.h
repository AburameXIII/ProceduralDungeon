// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "DungeonGen.generated.h"


const FVector2D CARDINAL[4] = { FVector2D(0,1),  FVector2D(0,-1), FVector2D(1,0), FVector2D(-1,0) };

UENUM()
enum ETileType {
	Empty, Wall, Water, Lava, Object, Enemy, RoomWall
};

USTRUCT()
struct FTile {
	GENERATED_BODY()
	ETileType Type;
	bool Room;
	int Region;
	FVector2D Coordinates;
};

USTRUCT()
struct FConnector {
	GENERATED_BODY()
    UPROPERTY()
	TArray<int> Regions;
	UPROPERTY()
	FVector2D Coordinates;
};


USTRUCT()
struct FRoom {
	GENERATED_BODY()
	UPROPERTY()
	int x;
	UPROPERTY()
	int y;
	UPROPERTY()
	int width;
	UPROPERTY()
	int height;
	UPROPERTY()
	int region;

	bool overlaps(FRoom OtherRoom, int padding) {
		//if Room is on the right of the OtherRoom or 
		bool OverlapX = (x >= OtherRoom.x - padding && x <= OtherRoom.x + OtherRoom.width + padding) ||
			(x + width >= OtherRoom.x - padding && x + width <= OtherRoom.x + OtherRoom.width + padding);
		bool OverlapY = (y >= OtherRoom.y - padding && y <= OtherRoom.y + OtherRoom.height + padding) ||
			(y + height >= OtherRoom.y - padding && y + height <= OtherRoom.y + OtherRoom.height + padding);
		return OverlapX && OverlapY;
	}

	bool operator==(const FRoom& OtherRoom) const {
		return x == OtherRoom.x && y == OtherRoom.y;
	}

};



UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class PROCEDURALDUNGEON_API UDungeonGen : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UDungeonGen();

	TArray<FTile> Generate();

	
	UPROPERTY()
	int RoomTries;

	UPROPERTY()
	float ExtraConnectorChance;

	UPROPERTY()
	int RoomMinSize;

	UPROPERTY()
	int RoomMaxSize;

	

	UPROPERTY()
	int Width;

	UPROPERTY()
	int Height;

	UPROPERTY()
	int RoomPadding;

	UPROPERTY()
	int WindingPercentage;

	UPROPERTY()
	TArray<FRoom> Rooms;

	UPROPERTY()
	TArray<FTile> DungeonArchitecture;


	//FOR MD ALGORITHM
	UPROPERTY()
		int HorizontalRooms;

	UPROPERTY()
		int VerticalRooms;

	UPROPERTY()
		int NumberOfRooms;
	

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	void AddRooms();
	bool Carve(FVector2D point, bool isRoom=false);
	void CarveRoomWall(FVector2D point);
	bool CanCarve(FVector2D point, FVector2D direction);
	void GrowMaze(int x, int y);
	void ConnectRegions();
	void ForceCarve(FVector2D p);
	void RemoveDeadEnds();

	void AddRoomsMD();
	void ConnectRegionsMD();
	bool CanConnectRight(FRoom r);
	bool CanConnectDown(FRoom r);
	void Connect(FRoom r1, FRoom r2);
	void ConnectTwoPoints(FVector2D p1, FVector2D p2);
	FRoom CreateMiniRoom(int r);
	void CarveRoom(FRoom r);
	FVector2D GetRandomRoomPoint(FRoom r);
	bool InBetween(int x, int y, int between);

	int CurrentRegion;
	FVector2D* LastDirection;
		
};
